![Alt text](Estatico/Imagenes/s2-minimized.png?raw=true "Optional Title")

# **Una página de apuestas de asignaturas de la Universidad De Cádiz**🏛
<li>✅Totalmente Gratuito</li>
<li>🔥Compite con tus amigos</li>
<li>💸Gana PINFCOINS</li>
<br>

👦Proyecto realizado por los alumnos de Ing.Informática por la Univ. De Cádiz:<br>
<li>Alejandro Serrano Fernández</li>
<li>Pedro Antonio Navas Luque</li>
<li>Antonio Morales Fernández</li>
<li>Juan Carlos Fernández Gallardo</li>
